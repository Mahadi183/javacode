package test;

//import org.junit.Test;
import org.testng.annotations.Test;


public class module1 {
	@Test
	public void test1() {
		System.out.println("Hello everyone");
		}
	@Test
	public void test2() {
		System.out.println("Daxmin Digital");
		}

}
