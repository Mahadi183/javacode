package test;

import org.testng.annotations.Test;

public class module2 {

	@Test
	public void test3() {
		System.out.println("You successfully Installed testng");
	}
}
