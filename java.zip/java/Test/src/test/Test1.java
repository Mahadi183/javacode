package test;

import org.junit.Test;

public class Test1 {
	@Test
	public void test() {
		System.out.println("test 1");
	}

}
