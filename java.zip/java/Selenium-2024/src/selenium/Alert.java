package selenium;

import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class Alert {

	public static void main(String[] args) {
		FirefoxOptions options = new FirefoxOptions();
		WebDriver driver = new FirefoxDriver(options);
		driver.get("file:///C:/Users/Mahadi%20Hasan/Desktop/alert.html");
		//driver.findElement(By.id("alert1")).click();
		//Alert alert = (Alert) driver.switchTo().alert();
		driver.findElement(By.id("alert2")).click();
		Alert confirmBox = (Alert)driver.switchTo().alert();
		//((Alert)confirmBox).dismiss();

	}

	

}
