package selenium;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Radio {

	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.get("file:///C:/Users/Mahadi%20Hasan/Desktop/radio.html");
		driver.findElement(By.xpath("/html/body/input[1]")).click();
		driver.findElements(By.xpath("//input[@name='group1']")).get(2).click();
		

	}

}
