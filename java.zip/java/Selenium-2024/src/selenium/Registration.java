package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Registration {

	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.get("file:///D:/automation-may-2024/html-css/form-test.html");
		driver.findElement(By.id("first")).sendKeys("Mahadi");
		driver.findElement(By.id("last")).sendKeys("Hasan");
		driver.findElement(By.id("email")).sendKeys("hmahadi183@gmail.com");
		driver.findElement(By.id("password")).sendKeys("Mahadi123");
		driver.findElement(By.id("conf-password")).sendKeys("Mahadi123");
		driver.findElement(By.xpath("//input[@name='male']")).click();
		driver.findElement(By.xpath("//input[@value='registration']")).click();

	}

}
