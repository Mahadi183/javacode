package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Checkbox {

	public static void main(String[] args) {
	     WebDriver driver = new ChromeDriver();
	     driver.get("file:///D:/automation-may-2024/html-css/checkbox.html");
	     WebElement checkbox = driver.findElement(By.id("check1"));
	     checkbox.click();
	     checkbox.click();

	}

}
