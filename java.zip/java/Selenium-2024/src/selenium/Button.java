package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Button {

	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.linkedin.com/signup/cold-join");
		driver.findElement(By.xpath("//*[@id=\"join-form-submit\"]")).click();

	}

}
