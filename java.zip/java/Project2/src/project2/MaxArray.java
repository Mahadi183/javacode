package project2;

public class MaxArray {

	public static void main(String[] args) {
		int[] number = {10,30,2,5,57,29,15,27};
		int max = number[0];
		for(int i =1;i<number.length;i++) {
			if(number[i]>max) {
				max = number[i];
			}
		}
		
		System.out.println("Maximum number is: "+max);

	}

}
