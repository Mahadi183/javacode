package project2;

public class While {

	public static void main(String[] args) {
		int i=15;
		int sum=0;
		while(i>=3) {
			
			sum = sum+i;
			i=i-4;
		}
		
		System.out.println("sum is: "+sum);

	}

}
