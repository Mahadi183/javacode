package project2;
import java.util.*;
public class ForLoop {

	public static void main(String[] args) {
		Scanner obj = new Scanner(System.in);
		System.out.print("Enter Initial value: ");
		int a = obj.nextInt();
		System.out.print("Enter last value: ");
		int b = obj.nextInt();
		for(int i =a; i<=b;i++) {
			
			if( i ==9) {
				break;
			}
			else {
			System.out.println(i);
			}
		}

	}

}
