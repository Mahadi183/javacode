package project2;

public class Ov {
	
	public void sum() {
		System.out.println("This is empty method");
		
	}
	
	public void sum(int a) {
		System.out.println("Here we receive one value: "+a);
		
	}
	
	public void sum(int a,int b) {
		System.out.println("Sum of 2 values are: "+(a+b));
		
	}

	public static void main(String[] args) {
		Ov obj = new Ov();
		obj.sum();
		obj.sum(10);
		obj.sum(8,9);
	

	}

}
