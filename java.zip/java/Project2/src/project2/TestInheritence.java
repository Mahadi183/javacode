package project2;

public class TestInheritence {

	public static void main(String[] args) {
		BabyDog b = new BabyDog();
		b.weep();
		b.bark();
		b.eat();

	}

}
