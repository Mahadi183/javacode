package project2;

public class Cons {
	
	Cons(){
		System.out.println("Empty parameter");
	}
	
	Cons(int a,int b){
		System.out.println("Sum of a and b is: "+(a+b));
	}

	public static void main(String[] args) {
		Cons obj1 = new Cons();
		Cons obj = new Cons(5,6);
		

	}

}
