package project2;

public class FirstClass {

	public static void main(String[] args) {
		
//		System.out.println("Hello everyone. This is our first java program");
//		System.out.println("Java is interesting");
		
		int num1 = 30;
		String name = "Mahadi";
		System.out.println("The value of the variable is "+num1);
		System.out.println("My name is "+name);
	}

}
