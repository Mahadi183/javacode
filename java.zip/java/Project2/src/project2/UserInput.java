package project2;
import java.util.*;
public class UserInput {

	public static void main(String[] args) {
		int num1, num2, sum,sub;
		Scanner obj = new Scanner(System.in);  // create scanner object
		System.out.print("Enter First Number: ");
		num1 = obj.nextInt();
		System.out.print("Enter second number: ");
		num2 = obj.nextInt();
		sum = num1+ num2;
		sub = num1 - num2;
		System.out.println("Sum is: "+sum);
		

	}

}
