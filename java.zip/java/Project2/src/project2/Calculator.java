package project2;

public class Calculator {

	public static void main(String[] args) {
		int num1 = 300;
		int num2 = 100;
		int addition = num1+num2;
		System.out.println("------------- Calculator ------------");
		System.out.println("Summation of two numbers are: "+addition);
		System.out.println("Substraction of two numbers are: "+(num1-num2));
		System.out.println("Multiplication of two numbers are: "+(num1*num2));
		System.out.println("Division of two numbers are: "+(num1/num2));
		System.out.println("Remainder of two numbers are: "+(num1%num2));

	}

}
