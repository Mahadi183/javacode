package project2;

public class A {
	
	int num1 = 10;
	int num2 = 20;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
