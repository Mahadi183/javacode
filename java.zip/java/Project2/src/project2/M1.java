package project2;

public class M1 {
	
	int num1=10;
	int num2 = 20;
	int sum;
	int sub;
	int mul;
	
	void AddNumbers() {
		sum = num1+num2;
		System.out.println("Sum is: "+sum);
	}
	
	void Substraction() {
		sub = num2-num1;
		System.out.println("Sub is: "+sub);
		
	}
	
	void multiplication() {
		mul = num1*num2;
		System.out.println("Mul is: "+mul);
		
	}

}
