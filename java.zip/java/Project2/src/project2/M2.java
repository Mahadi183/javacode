package project2;

public class M2 {
	
	int num1=13;
	int num2 = 10;
	int sum;
	
	int info() {
		sum = num1 + num2;
		System.out.println("we are performing addition operation");
		return sum;
	}
	
	int sum(int a,int b) {
		return a*b;
	}

}
