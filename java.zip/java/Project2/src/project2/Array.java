package project2;

public class Array {

	public static void main(String[] args) {
		int b[] = {3,5,10,9,2,17};
		int sum=0;
		for(int i=0;i<b.length;i++) {
			sum = sum + b[i];
		}
		
		System.out.println("sum is: "+sum);

	}

}
