package project2;

public class Operator {
	static int a =5;

	public static void main(String[] args) {
		Operator obj = new Operator();
		
		float typecast = 20.91f;
		int b = (int)typecast;
		int a=10;
		System.out.println(typecast);
		System.out.println(b);
		//preincrement
		int y = 7;
		int k = 10;
		System.out.println(y);
		System.out.println(++y);  // int y =8;
		System.out.println(y);
		System.out.println(y++); // int y =9;
		System.out.println(++y);
		System.out.println(--k); // int k =9;
		k++; // k =10
		System.out.println(++k); // k =11
		System.out.println(k++ + --k);
		System.out.println(a);
	}

}
