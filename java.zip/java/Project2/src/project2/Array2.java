package project2;

public class Array2 {

	public static void main(String[] args) {
		
		int[] myArr = {13,4,5,2,10};
		String[] fruits = {"Apple","Cherry","Pineapple","Orange","Mango"};
		for(int i=0;i<myArr.length;i++) {
			System.out.println("index "+i+" is "+myArr[i]);
		}	
		
		for(int i=0;i<fruits.length;i++) {
			System.out.println("index "+i+" is "+fruits[i]);
		}
	
	}

}
