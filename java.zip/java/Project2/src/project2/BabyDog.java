package project2;

public class BabyDog extends Dog {
	void weep() {
		System.out.println("weeping");
	}

}
