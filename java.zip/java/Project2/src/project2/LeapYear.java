package project2;
import java.util.*;
public class LeapYear {

	public static void main(String[] args) {
		Scanner obj = new Scanner(System.in);
		System.out.print("Enter a year to check leap year: ");
		int year = obj.nextInt();
		if((year % 400 == 0)|| (year % 4 == 0 && year % 100 !=0)) {
			System.out.println("Leap Year");
		}
		else {
			System.out.println("Not a leap year");
		}

	}

}
