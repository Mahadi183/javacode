package project2;

public class ClassObject {
	
	int num =5; // instance 
	String name = "Mahadi";

	public static void main(String[] args) {
		
		ClassObject obj = new ClassObject();
		ClassObject obj2 = new ClassObject();
		A obj3 = new A();
		
		System.out.println(obj.num);
		System.out.println(obj2.name);
		System.out.println(obj3.num1);
		System.out.println(obj3.num2);
	

	}

}
