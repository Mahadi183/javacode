package project2;

public class Dog extends Animal {
	void bark() {
		System.out.println("barking....");
		}

}
