package multiple_inheritence;

public interface Animal {
	void eat();
    void sleep();

}
