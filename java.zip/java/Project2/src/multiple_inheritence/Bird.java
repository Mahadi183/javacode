package multiple_inheritence;

public interface Bird {
	void fly();
    void sing();

}
