package multiple_inheritence;

public class Sparrow implements Animal,Bird {
	
	public void eat() {
        System.out.println("Sparrow is eating.");
    }

   
    public void sleep() {
        System.out.println("Sparrow is sleeping.");
    }

    
    public void fly() {
        System.out.println("Sparrow is flying.");
    }

   
    public void sing() {
        System.out.println("Sparrow is singing.");
    }

}
