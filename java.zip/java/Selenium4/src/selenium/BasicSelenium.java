package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class BasicSelenium {

	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
//		driver.get("https://www.ox.ac.uk/");
//		driver.findElement(By.id("edit-submit")).click();
//		driver.get("https://www.northsouth.edu/");
//		driver.findElement(By.xpath("//a[@href='http://apply.northsouth.edu:8080/admissionWeb/login.view']")).click();
		
		driver.get("https://demo.opencart.com/");
		
			
		

	}

}
