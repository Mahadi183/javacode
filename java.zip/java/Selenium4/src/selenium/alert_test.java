package selenium;

import org.openqa.selenium.By;  
import org.openqa.selenium.WebDriver;  
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.Alert;  
public class alert_test {  
  
    public static void main(String[] args) {  
          

              
        // Initialize Gecko Driver using Desired Capabilities Class  
           // DesiredCapabilities capabilities = DesiredCapabilities.firefox(); 
    	
           // capabilities.setCapability("marionette",true);  
           // WebDriver driver= new FirefoxDriver(capabilities);  
    	// Initialize FirefoxOptions and set desired capabilities
        FirefoxOptions options = new FirefoxOptions();
       

        // Initialize FirefoxDriver with FirefoxOptions
        WebDriver driver = new FirefoxDriver(options);

          
  
        // Launch Website  
        driver.get("file:///C:/Users/Mahadi%20Hasan/Desktop/alert.html");   
  
        //Handling alert boxes  
        //Click on generate alert button  
        driver.findElement(By.id("alert1")).click();  
          
        //Using Alert class to first switch to or focus to the alert box  
        Alert alert = (Alert) driver.switchTo().alert();  
          
        //Using accept() method to accept the alert box  
        alert.accept();  
          
        //Handling confirm box  
        //Click on Generate Confirm Box  
        driver.findElement(By.id("alert2")).click();  
          
          
        Alert confirmBox = (Alert) driver.switchTo().alert();  
          
        //Using dismiss() command to dismiss the confirm box  
        //Similarly accept can be used to accept the confirm box  
       ((Alert) confirmBox).dismiss();  
  
  
      
    }  
  
}  

