package selenium;

import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;

public class alert_test1 {

	public static void main(String[] args) {
		ChromeOptions options = new ChromeOptions();
		WebDriver driver = new ChromeDriver(options);
		driver.get("file:///D:/automation-batch-project/alert-test.html");
		driver.findElement(By.id("alert1")).click();
		Alert alert = (Alert) driver.switchTo().alert(); 
		alert.accept();
		driver.findElement(By.id("alert2")).click();
		Alert confirmBox = (Alert) driver.switchTo().alert(); 
		 ((Alert) confirmBox).dismiss(); 


	}

}
