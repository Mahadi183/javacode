package selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Sel1 {

	public static void main(String[] args) {
		ChromeDriver driver = new ChromeDriver();
		WebDriver driver1 = new ChromeDriver();

	}

}
