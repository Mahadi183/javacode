package test;

//import org.junit.Test;
import org.testng.annotations.Test;

public class module2 {
	@Test
	public void test3() {
		System.out.println("You successfully Installed testng");
	}
	@Test
	public void test4() {
		System.out.println("test 4");
	}
}
