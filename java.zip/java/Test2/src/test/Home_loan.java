package test;

import org.testng.annotations.Test;

public class Home_loan {
	@Test
	public void home_loan() {
		System.out.println("home loan");
	}

}
