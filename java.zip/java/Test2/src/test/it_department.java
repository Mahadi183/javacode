package test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class it_department {
	@BeforeTest
	public void before_test() {
		System.out.println("it will be executed first");
	}
	@Test
	public void software_developers() {
		System.out.println("Software Developers");
	}
	@BeforeMethod
	public void software_testers() {
		System.out.println("Software Testers");
	}
	@Test
	public void qa_analyst() {
		System.out.println("QA Analyst");
	}

}
