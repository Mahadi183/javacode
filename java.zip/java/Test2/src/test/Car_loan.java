package test;

import org.testng.annotations.AfterSuite;
//import org.testng.annotations.Test;

public class Car_loan {
	
	@AfterSuite
	public void car_loan() {
		System.out.println("car loan");
		}

}
