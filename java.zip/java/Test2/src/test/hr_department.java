package test;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class hr_department {
	@Test
	public void manager() {
		System.out.println("Manager");
	}
	@BeforeClass
	public void hr() {
		System.out.println("HR");
	}
	@Test
	public void counsellor() {
		System.out.println("Counsellor");
	}

}
