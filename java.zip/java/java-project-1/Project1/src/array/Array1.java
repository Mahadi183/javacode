package array;

public class Array1 {

	public static void main(String[] args) {
		int a[] = {10,20,15,5,50};
		for(int i =0;i<a.length;i++) {
			System.out.println(a[i]);
		}
	}

}
