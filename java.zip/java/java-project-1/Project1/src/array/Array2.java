package array;

public class Array2 {

	public static void main(String[] args) {
		int arr[][] = {{10,5,2},{14,15,6},{17,21,13}};
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				System.out.print(arr[i][j]+" ");
			}
			System.out.println();
		}

	}

}
