package method;

public class Method2 {
	
	String evenorodd(int num) {
		if(num%2==0) {
			return "even";
		}
		else {
			return "odd";
		}
	}

}
