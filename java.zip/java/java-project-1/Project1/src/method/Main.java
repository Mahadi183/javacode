package method;

public class Main {

	public static void main(String[] args) {
		Method obj = new Method();
		Method2 obj1 = new Method2();
		System.out.println(obj.sum(10, 20));
		System.out.println(obj.sum(15, 17));
		System.out.println(obj1.evenorodd(17));
	}

}
