package whileloop;

public class Info {
	
	String student_name="Nazim";
	String city="New York";

}
