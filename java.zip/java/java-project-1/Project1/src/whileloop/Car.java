package whileloop;

public class Car {
	
	String color = "black";
	 int a = 10;
	
	

	public static void main(String[] args) {
		
		CarInfo obj = new CarInfo();
		Student obj1 = new Student();
		Car obj2 = new Car();
		System.out.println(obj.price);
		System.out.println(obj1.current_class);
		System.out.println(obj2.a);
	}

}
