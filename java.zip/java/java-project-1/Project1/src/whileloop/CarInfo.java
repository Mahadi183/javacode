package whileloop;

public class CarInfo {
	
	String car_name = "Toyota";
	String color = "black";
	int price = 50000;

}
