package whileloop;

public class Student {
	
	String current_class = "twelve";
	

	public static void main(String[] args) {
		
		int student_number = 120;
		Info ob = new Info();
		Car obj1 = new Car();
		System.out.println(ob.student_name);
		System.out.println(ob.city);
		System.out.println(obj1.color);
		System.out.println(student_number);
	}

}
