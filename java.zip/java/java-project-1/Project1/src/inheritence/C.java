package inheritence;

public class C extends A{

	public static void main(String[] args) {
		C obj = new C();
		System.out.println(obj.age);

	}

}
