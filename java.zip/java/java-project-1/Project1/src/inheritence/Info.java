package inheritence;

public class Info {
	int age = 34;

}
