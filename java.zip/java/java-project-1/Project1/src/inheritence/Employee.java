package inheritence;

public class Employee extends Info{
	
  int salary = 40000;
}
